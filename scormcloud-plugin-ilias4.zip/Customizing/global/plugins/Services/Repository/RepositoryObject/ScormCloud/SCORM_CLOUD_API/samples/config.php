<?php  /// Configuration File 

unset($CFG);

$CFG->wwwroot = "http://localhost/dokeos/main/scorm_cloud/CloudPHPLibrary/samples/";

//Rustici Software SCORM Cloud API Key Settings
$CFG->scormcloudurl = 'http://dev.cloud.scorm.com/EngineWebServices/';
$CFG->scormcloudsecretkey = '0KxLw3ksj7fyGwPWPfKL3t6s9N5EHpGMIZp9VHUG';
$CFG->scormcloudappid = 'troy';

//$CFG->scormcloudurl = 'http://cloud.scorm.com/EngineWebServices/';
//$CFG->scormcloudsecretkey = 'Ng54NJ66ydQwCSWWcDC21lraJxwc3Sv4I7lrvBx1';
//$CFG->scormcloudappid = 'remote-learner';


?>