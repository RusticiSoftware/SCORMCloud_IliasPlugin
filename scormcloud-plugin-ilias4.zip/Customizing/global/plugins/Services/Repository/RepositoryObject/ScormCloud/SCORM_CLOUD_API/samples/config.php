<?php  /// Configuration File 

unset($CFG);

$CFG->wwwroot = "http://localhost/cloudlib/samples/";

//Rustici Software SCORM Cloud API Key Settings
$CFG->scormcloudurl = 'http://dev.cloud.scorm.com/EngineWebServices/';
$CFG->scormcloudsecretkey = '32wE8eRYmMKy5Rcl171ZrR3lSIj2a4QyZXbwWZE7';
$CFG->scormcloudappid = 'john';

//$CFG->scormcloudurl = 'http://cloud.scorm.com/EngineWebServices/';
//$CFG->scormcloudsecretkey = 'Ng54NJ66ydQwCSWWcDC21lraJxwc3Sv4I7lrvBx1';
//$CFG->scormcloudappid = 'remote-learner';


?>