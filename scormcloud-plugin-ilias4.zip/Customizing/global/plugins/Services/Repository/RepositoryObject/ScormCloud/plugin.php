<?php
 
// alphanumerical ID of the plugin; never change this
$id = "xscl";
 
// code version; must be changed for all code changes
$version = "0.0.9";
 
// ilias min and max version; must always reflect the versions that should
// run with the plugin
$ilias_min_version = "4.0.0";
$ilias_max_version = "4.0.999";
 
// optional, but useful: Add one or more responsible persons and a contact email
$responsible = "John Hayden";
$responsible_mail = "john.hayden at scorm.com";

//
global $scormcloud_url, $scormcloud_app_id, $scormcloud_secret_key;
$scormcloud_url	= 'http://dev.cloud.scorm.com/EngineWebServices';
$scormcloud_app_id = 'john';
$scormcloud_secret_key = '32wE8eRYmMKy5Rcl171ZrR3lSIj2a4QyZXbwWZE7';


?>
